/*
 * Sample string module largely borrowed from https://github.com/metthal/IFJ-Projekt
 */

#include "string2.h"

static uint16_t const STRING_DEFAULT_SIZE = 16;

void init2String(String *ps)
{
    uint32_t size = STRING_DEFAULT_SIZE;
    ps->data = malloc(sizeof(char) * size);
    if (ps->data != NULL) {
      ps->data[0] = '\0';
      ps->size = size;
      ps->length = 1;
    }
}

void delete2String(String *ps)
{
    if (ps != NULL) {
        free(ps->data);
        ps->data = NULL;
        ps->size = 0;
        ps->length = 0;
    }
}

int isString2Empty(String *ps)
{
    if (ps == NULL)
      return 1;
    return 0;
}
