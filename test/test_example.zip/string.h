/*
 * Sample string module largely borrowed from https://github.com/metthal/IFJ-Projekt
 */

#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>

typedef struct
{
    uint32_t size;
    uint32_t length;
    char *data;
} String;

void initString(String *ps);
void deleteString(String *ps);
int isStringEmpty(String *ps);
