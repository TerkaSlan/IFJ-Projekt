/*
 * Testing module borrowed from https://github.com/metthal/IFJ-Projekt
 */

#include "test.h"
#include "../string.h"

TEST_SUITE_START(StringTest);
// initString()
String x;
initString(&x);
SHOULD_EQUAL("initString() Length", x.length, 2);
SHOULD_EQUAL_STR("initString() Data", x.data, "");

// stringEmpty()
isStringEmpty(&x);
SHOULD_EQUAL("stringEmpty() Length", x.length, 1);
SHOULD_EQUAL_STR("stringEmpty() Data", x.data, "");

// deleteString()
deleteString(&x);
SHOULD_EQUAL("delete() Size", x.size, 0);
SHOULD_EQUAL("delete() Length", x.length, 0);
SHOULD_EQUAL("delete() Data", x.data, NULL);

TEST_SUITE_END
